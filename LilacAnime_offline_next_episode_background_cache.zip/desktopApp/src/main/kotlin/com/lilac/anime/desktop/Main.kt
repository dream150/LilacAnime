package com.lilac.anime.desktop

import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application

fun main() = application {
    Window(
        onCloseRequest = ::exitApplication,
        title = "LilacAnime Desktop"
    ) {
        DesktopApp()
    }
}
